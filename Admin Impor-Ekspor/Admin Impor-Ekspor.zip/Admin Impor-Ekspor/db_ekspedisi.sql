-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 08 Jul 2024 pada 05.28
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

/*
    Hak Cipta © 2024 Mochamad Naufal Shofy
    Web ini telah dilesensikan
    Repository GitHub: https://github.com/nopalsh/3-web-projects
*/

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ekspedisi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_barang`
--

CREATE TABLE `detail_barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `tipe_barang` varchar(100) DEFAULT NULL,
  `jumlah` int(11) NOT NULL,
  `berat` decimal(10,2) NOT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `detail_barang`
--

INSERT INTO `detail_barang` (`id_barang`, `nama_barang`, `tipe_barang`, `jumlah`, `berat`, `deskripsi`) VALUES
(67, 'Kaca Gedung', 'Paket', 100, 100.00, 'Kaca untuk gedung ukuran 5x5m'),
(68, 'Kaca Gedung 2', 'Paket', 100, 100.00, 'Kaca untuk gedung ukuran 5x5m'),
(69, 'Kaca Gedung 3', 'Paket', 100, 100.00, 'Kaca untuk gedung ukuran 5x5m'),
(70, 'Kaca Gedung 4', 'Paket', 100, 100.00, 'Kaca untuk gedung ukuran 5x5m');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ekspor_barang`
--

CREATE TABLE `ekspor_barang` (
  `id_ekspor` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `negara_penerima` varchar(100) NOT NULL,
  `nama_penerima` varchar(100) NOT NULL,
  `alamat_penerima` varchar(255) NOT NULL,
  `kode_pos_penerima` varchar(20) NOT NULL,
  `status` varchar(50) DEFAULT 'Permintaan Persetujuan',
  `tanggal_ekspor` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `nama_pengirim` varchar(255) NOT NULL,
  `alamat_pengirim` varchar(100) DEFAULT NULL,
  `kode_pos_pengirim` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `ekspor_barang`
--

INSERT INTO `ekspor_barang` (`id_ekspor`, `id_barang`, `id_pengguna`, `negara_penerima`, `nama_penerima`, `alamat_penerima`, `kode_pos_penerima`, `status`, `tanggal_ekspor`, `nama_pengirim`, `alamat_pengirim`, `kode_pos_pengirim`) VALUES
(693031, 68, 62, '65', 'Lan Company', 'Street No. 00', '1200', 'Disetujui Importir', '2024-07-07 15:57:53', 'PT. Kinlon Hardware Indonesia', 'Jalan Raya No. 11 Jakarta', '1300'),
(734443, 70, 65, '62', 'Lan Company', 'Street No. 00', '1200', 'Permintaan Persetujuan', '2024-07-07 16:06:06', 'PT. Kinlon Hardware Indonesia', 'Jalan Raya No. 11 Jakarta', '1300'),
(825529, 69, 65, '62', 'Lan Company', 'Street No. 00', '1200', 'Disetujui Importir', '2024-07-07 15:58:57', 'PT. Kinlon Hardware Indonesia', 'Jalan Raya No. 11 Jakarta', '1300'),
(950878, 67, 62, '65', 'Lan Company', 'Street No. 00', '1200', 'Disetujui Importir', '2024-07-07 15:56:39', 'PT. Kinlon Hardware Indonesia', 'Jalan Raya No. 11 Jakarta', '1300');

-- --------------------------------------------------------

--
-- Struktur dari tabel `history_timeline`
--

CREATE TABLE `history_timeline` (
  `id_tracking_timeline` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `status_barang` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `tanggal_update` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `history_timeline`
--

INSERT INTO `history_timeline` (`id_tracking_timeline`, `id_tracking`, `status_barang`, `keterangan`, `tanggal_update`) VALUES
(49, 230259, 'Disetujui Importir', 'Barang telah disetujui importir', '2024-07-07 15:56:39'),
(50, 229827, 'Disetujui Importir', 'Barang telah disetujui importir', '2024-07-07 15:57:53'),
(51, 798050, 'Disetujui Importir', 'Barang telah disetujui importir', '2024-07-07 15:58:57'),
(52, 229827, 'Diproses', 'Pesanan sedang diproses.', '2024-07-07 16:08:07'),
(53, 230259, 'Diproses', 'Pesanan sedang diproses.', '2024-07-07 16:08:13'),
(54, 798050, 'Diproses', 'Pesanan sedang diproses.', '2024-07-07 16:08:16'),
(55, 230259, 'Dikirim', 'Pesanan telah dikirim.', '2024-07-07 16:08:19'),
(56, 229827, 'Dikirim', 'Pesanan telah dikirim.', '2024-07-07 16:08:22'),
(57, 229827, 'Selesai', 'Pesanan telah selesai.', '2024-07-07 16:08:26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `impor_barang`
--

CREATE TABLE `impor_barang` (
  `id_impor` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `negara_pengirim` varchar(100) NOT NULL,
  `nama_penerima` varchar(100) NOT NULL,
  `alamat_penerima` varchar(255) NOT NULL,
  `kode_pos_penerima` varchar(20) NOT NULL,
  `status` varchar(50) DEFAULT 'Permintaan Persetujuan',
  `tanggal_impor` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `nama_pengirim` varchar(255) NOT NULL,
  `alamat_pengirim` varchar(100) DEFAULT NULL,
  `kode_pos_pengirim` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `impor_barang`
--

INSERT INTO `impor_barang` (`id_impor`, `id_barang`, `id_pengguna`, `negara_pengirim`, `nama_penerima`, `alamat_penerima`, `kode_pos_penerima`, `status`, `tanggal_impor`, `nama_pengirim`, `alamat_pengirim`, `kode_pos_pengirim`) VALUES
(693031, 68, 65, '62', 'Lan Company', 'Street No. 00', '1200', 'Disetujui Importir', '2024-07-07 15:57:53', 'PT. Kinlon Hardware Indonesia', 'Jalan Raya No. 11 Jakarta', '1300'),
(734443, 70, 62, '65', 'Lan Company', 'Street No. 00', '1200', 'Permintaan Persetujuan', '2024-07-07 16:06:06', 'PT. Kinlon Hardware Indonesia', 'Jalan Raya No. 11 Jakarta', '1300'),
(825529, 69, 62, '65', 'Lan Company', 'Street No. 00', '1200', 'Disetujui Importir', '2024-07-07 15:58:57', 'PT. Kinlon Hardware Indonesia', 'Jalan Raya No. 11 Jakarta', '1300'),
(950878, 67, 65, '62', 'Lan Company', 'Street No. 00', '1200', 'Disetujui Importir', '2024-07-07 15:56:39', 'PT. Kinlon Hardware Indonesia', 'Jalan Raya No. 11 Jakarta', '1300');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `user_pengguna` varchar(100) NOT NULL,
  `kata_sandi` varchar(255) NOT NULL,
  `negara` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `user_pengguna`, `kata_sandi`, `negara`) VALUES
(62, 'idn', 'idn', 'Indonesia'),
(65, 'sgp', 'sgp', 'Singapura');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tracking_barang`
--

CREATE TABLE `tracking_barang` (
  `id_tracking` int(11) NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `id_impor` int(11) DEFAULT NULL,
  `id_ekspor` int(11) DEFAULT NULL,
  `status_barang` varchar(100) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `tanggal_update` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tracking_barang`
--

INSERT INTO `tracking_barang` (`id_tracking`, `id_pengguna`, `id_impor`, `id_ekspor`, `status_barang`, `keterangan`, `tanggal_update`) VALUES
(229827, 65, 693031, 693031, 'Selesai', 'Pesanan telah selesai.', '2024-07-07 15:57:53'),
(230259, 65, 950878, 950878, 'Dikirim', 'Pesanan telah dikirim.', '2024-07-07 15:56:39'),
(798050, 62, 825529, 825529, 'Diproses', 'Pesanan sedang diproses.', '2024-07-07 15:58:57');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `detail_barang`
--
ALTER TABLE `detail_barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indeks untuk tabel `ekspor_barang`
--
ALTER TABLE `ekspor_barang`
  ADD PRIMARY KEY (`id_ekspor`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_pengguna` (`id_pengguna`);

--
-- Indeks untuk tabel `history_timeline`
--
ALTER TABLE `history_timeline`
  ADD PRIMARY KEY (`id_tracking_timeline`),
  ADD KEY `fk_history_tracking` (`id_tracking`);

--
-- Indeks untuk tabel `impor_barang`
--
ALTER TABLE `impor_barang`
  ADD PRIMARY KEY (`id_impor`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_pengguna` (`id_pengguna`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indeks untuk tabel `tracking_barang`
--
ALTER TABLE `tracking_barang`
  ADD PRIMARY KEY (`id_tracking`),
  ADD KEY `id_pengguna` (`id_pengguna`),
  ADD KEY `id_impor` (`id_impor`),
  ADD KEY `id_ekspor` (`id_ekspor`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `detail_barang`
--
ALTER TABLE `detail_barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT untuk tabel `ekspor_barang`
--
ALTER TABLE `ekspor_barang`
  MODIFY `id_ekspor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=950879;

--
-- AUTO_INCREMENT untuk tabel `history_timeline`
--
ALTER TABLE `history_timeline`
  MODIFY `id_tracking_timeline` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT untuk tabel `impor_barang`
--
ALTER TABLE `impor_barang`
  MODIFY `id_impor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=950879;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT untuk tabel `tracking_barang`
--
ALTER TABLE `tracking_barang`
  MODIFY `id_tracking` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=805504;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `ekspor_barang`
--
ALTER TABLE `ekspor_barang`
  ADD CONSTRAINT `ekspor_barang_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `detail_barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ekspor_barang_ibfk_2` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `history_timeline`
--
ALTER TABLE `history_timeline`
  ADD CONSTRAINT `fk_history_tracking` FOREIGN KEY (`id_tracking`) REFERENCES `tracking_barang` (`id_tracking`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `impor_barang`
--
ALTER TABLE `impor_barang`
  ADD CONSTRAINT `impor_barang_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `detail_barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `impor_barang_ibfk_2` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tracking_barang`
--
ALTER TABLE `tracking_barang`
  ADD CONSTRAINT `tracking_barang_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tracking_barang_ibfk_2` FOREIGN KEY (`id_impor`) REFERENCES `impor_barang` (`id_impor`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tracking_barang_ibfk_3` FOREIGN KEY (`id_ekspor`) REFERENCES `ekspor_barang` (`id_ekspor`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


