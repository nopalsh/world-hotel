<?php
require_once "koneksi.php";
session_start();
if (!isset($_SESSION["id_pengguna"])) {
    header("Location: login.php"); 
    exit();
}

$id_pengguna = $_SESSION["id_pengguna"];
$query_impor_count = "SELECT COUNT(*) AS impor_count FROM impor_barang WHERE status = 'Disetujui Importir' AND id_pengguna = $id_pengguna";
$result_impor_count = mysqli_query($conn, $query_impor_count);
$row_impor_count = mysqli_fetch_assoc($result_impor_count);
$impor_count = $row_impor_count['impor_count'];
$query_ekspor_count = "SELECT COUNT(*) AS ekspor_count FROM ekspor_barang WHERE status = 'Disetujui Importir' AND id_pengguna = $id_pengguna";
$result_ekspor_count = mysqli_query($conn, $query_ekspor_count);
$row_ekspor_count = mysqli_fetch_assoc($result_ekspor_count);
$ekspor_count = $row_ekspor_count['ekspor_count'];
$query_impor_status_count = "SELECT COUNT(*) AS impor_status_count FROM impor_barang WHERE status = 'Permintaan Persetujuan' AND id_pengguna = $id_pengguna";
$result_impor_status_count = mysqli_query($conn, $query_impor_status_count);
$row_impor_status_count = mysqli_fetch_assoc($result_impor_status_count);
$impor_status_count = $row_impor_status_count['impor_status_count'];
$query_ekspor_status_count = "SELECT COUNT(*) AS ekspor_status_count FROM ekspor_barang WHERE status = 'Permintaan Persetujuan' AND id_pengguna = $id_pengguna";
$result_ekspor_status_count = mysqli_query($conn, $query_ekspor_status_count);
$row_ekspor_status_count = mysqli_fetch_assoc($result_ekspor_status_count);
$ekspor_status_count = $row_ekspor_status_count['ekspor_status_count'];
$query_impor_count = "SELECT DATE_FORMAT(tanggal_impor, '%Y-%m-%d') AS tanggal, COUNT(*) AS jumlah FROM impor_barang WHERE id_pengguna = $id_pengguna GROUP BY DATE_FORMAT(tanggal_impor, '%Y-%m-%d')";
$result_impor_count = mysqli_query($conn, $query_impor_count);
$impor_dates = array();
$impor_counts = array();

while ($row = mysqli_fetch_assoc($result_impor_count)) {
    $impor_dates[] = $row['tanggal'];
    $impor_counts[] = $row['jumlah'];
}

$query_ekspor_count = "SELECT DATE_FORMAT(tanggal_ekspor, '%Y-%m-%d') AS tanggal, COUNT(*) AS jumlah FROM ekspor_barang WHERE id_pengguna = $id_pengguna GROUP BY DATE_FORMAT(tanggal_ekspor, '%Y-%m-%d')";
$result_ekspor_count = mysqli_query($conn, $query_ekspor_count);

$ekspor_dates = array();
$ekspor_counts = array();

while ($row = mysqli_fetch_assoc($result_ekspor_count)) {
    $ekspor_dates[] = $row['tanggal'];
    $ekspor_counts[] = $row['jumlah'];
}

$data_impor = array(
    'dates' => $impor_dates,
    'counts' => $impor_counts
);

$data_ekspor = array(
    'dates' => $ekspor_dates,
    'counts' => $ekspor_counts
);
?>
<!DOCTYPE html>
<html data-bs-theme="light" lang="en" style="font-family: Poppins, sans-serif;">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Ekspedisi</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/Navbar-Right-Links-icons.css">
    <link rel="stylesheet" href="style.css">
</head>
<body id="page-top">
    <div id="wrapper" style="font-family: Poppins, sans-serif;">
        <div class="d-flex flex-column" id="content-wrapper" style="background: #f8f9fb;">
            <div id="wrapper">
                <nav class="navbar align-items-start sidebar accordion"
                    style="background: #fff; border-right: 1px solid #eeeeee;">
                    <div class="container-fluid d-flex flex-column p-0">
                        <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0"
                            href="#">
                            <div class="sidebar-brand-icon rotate-n-15">
                                <i class="fas fa-truck-loading" style="color: #142fb3;"></i>
                            </div>
                            <div class="sidebar-brand-text mx-3"><span style="color: #000000;">EKSPEDISI</span></div>
                        </a>
                        <hr class="sidebar-divider my-0" />
                        <ul id="accordionSidebar" class="navbar-nav text-light">
                           <li class="nav-item">
                                <a class="nav-link active" href="index.php"
								style="background: #dadcef;border-width: 10px;border-color: rgb(0,0,0);border-left: 5px solid #142fb3;" >
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -32 576 576" width="1em"
                                        height="1em" fill="currentColor"
                                        style="color: #3f4d95; position: relative; margin-top: 0; margin-right: 8px;">
                                        <path
                                            d="M511.8 287.6L512.5 447.7C512.5 450.5 512.3 453.1 512 455.8V472C512 494.1 494.1 512 472 512H456C454.9 512 453.8 511.1 452.7 511.9C451.3 511.1 449.9 512 448.5 512H392C369.9 512 352 494.1 352 472V384C352 366.3 337.7 352 320 352H256C238.3 352 224 366.3 224 384V472C224 494.1 206.1 512 184 512H128.1C126.6 512 125.1 511.9 123.6 511.8C122.4 511.9 121.2 512 120 512H104C81.91 512 64 494.1 64 472V360C64 359.1 64.03 358.1 64.09 357.2V287.6H32.05C14.02 287.6 0 273.5 0 255.5C0 246.5 3.004 238.5 10.01 231.5L266.4 8.016C273.4 1.002 281.4 0 288.4 0C295.4 0 303.4 2.004 309.5 7.014L416 100.7V64C416 46.33 430.3 32 448 32H480C497.7 32 512 46.33 512 64V185L564.8 231.5C572.8 238.5 576.9 246.5 575.8 255.5C575.8 273.5 560.8 287.6 543.8 287.6L511.8 287.6z">
                                        </path>
                                    </svg>

									<b><span style="color: #3f4d95;">Beranda</span></b>

                                </a>
                                <a class="nav-link active" href="impor.php"
                                   >
                                    <svg class="bi bi-box-arrow-in-down" xmlns="http://www.w3.org/2000/svg" width="1em"
                                        height="1em" fill="currentColor" viewBox="0 0 16 16"
                                        style="color: #6a6b83; position: relative; margin-top: -8px; margin-right: 8px;">
                                        <path fill-rule="evenodd"
                                            d="M3.5 6a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-8a.5.5 0 0 0-.5-.5h-2a.5.5 0 0 1 0-1h2A1.5 1.5 0 0 1 14 6.5v8a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 14.5v-8A1.5 1.5 0 0 1 3.5 5h2a.5.5 0 0 1 0 1h-2z">
                                        </path>
                                        <path fill-rule="evenodd"
                                            d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z">
                                        </path>
                                    </svg>
                                    <span style="color: #3f4d95; font-weight: normal !important;">Data Impor</span>
                                </a>
                                <a class="nav-link active" href="ekspor.php">
                                    <svg class="bi bi-box-arrow-in-up" xmlns="http://www.w3.org/2000/svg" width="1em"
                                        height="1em" fill="currentColor" viewBox="0 0 16 16"
                                        style="color: #6a6b83; position: relative; margin-top: 0; margin-right: 8px;">
                                        <path fill-rule="evenodd"
                                            d="M3.5 10a.5.5 0 0 1-.5-.5v-8a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 0 0 1h2A1.5 1.5 0 0 0 14 9.5v-8A1.5 1.5 0 0 0 12.5 0h-9A1.5 1.5 0 0 0 2 1.5v8A1.5 1.5 0 0 0 3.5 11h2a.5.5 0 0 0 0-1h-2z">
                                        </path>
                                        <path fill-rule="evenodd"
                                            d="M7.646 4.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 5.707V14.5a.5.5 0 0 1-1 0V5.707L5.354 7.854a.5.5 0 1 1-.708-.708l3-3z">
                                        </path>
                                    </svg>
                                    <span style="color: #6a6b83;">
									<span style="font-weight: normal !important;">Data Ekspor</span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="container-fluid" style="padding: 0; margin: 0;">
                    <nav class="navbar navbar-expand mb-4 topbar static-top navbar-light navbar-dark" style="background: #142fb3; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #eeeeee;">
                        <div class="container-fluid">
						<h5 style="color: white; font-weight: bold; margin-top: 5px;">Beranda</h5>
                        <ul class="navbar-nav flex-nowrap ms-auto" style="margin: 0;">
                                <div class="d-none d-sm-block topbar-divider"></div>
                                <li class="nav-item dropdown no-arrow">
                                    <div class="nav-item dropdown no-arrow">
                                        <a class="dropdown-toggle nav-link" aria-expanded="false"
                                            data-bs-toggle="dropdown" href="#" style="color: white;">
                                            <?php
                                            $id_pengguna = $_SESSION['id_pengguna'];
                                            $query = "SELECT negara FROM pengguna WHERE id_pengguna = $id_pengguna";
                                            $result = $conn->query($query);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $negara = $row['negara'];
                                                    echo "<span class='d-none d-lg-inline me-2 small'>$negara</span>";
                                                }
                                            }
                                            ?>
                                            <img class="border rounded-circle img-profile"
											src="https://t3.ftcdn.net/jpg/05/14/18/46/360_F_514184651_W5rVCabKKRH6H3mVb62jYWfuXio8c8si.jpg" />
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end animated--grow-in">
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="logout.php" style="color: black;">
                                                <i class="fas fa-sign-out-alt fa-sm fa-fw me-2 text-gray-400"></i>
                                                Keluar </a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
					<div class="container-fluid">
                    <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #1cc88a;">Impor<br/> </div>
                                            <div class="text-dark fw-bold h5 mb-0"><?php echo $impor_count; ?></div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-truck-loading fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #4e73df;">Ekspor</div>
                                            <div class="text-dark fw-bold h5 mb-0"><?php echo $ekspor_count; ?></div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-box fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #f6c23e;">Meminta Persetujuan Impor</div>
                                            <div class="text-dark fw-bold h5 mb-0"><?php echo $impor_status_count; ?></div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-clock fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row align-items-center no-gutters">
                                        <div class="col me-2">
                                            <div class="text-uppercase text-primary fw-bold text-xs mb-1" style="color: #e74a3b;">Permintaan Persetujuan Ekspor</div>
                                            <div class="text-dark fw-bold h5 mb-0"><?php echo $ekspor_status_count; ?></div>
                                        </div>
                                        <div class="col-auto"><i class="fas fa-calendar fa-2x text-gray-300"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Distribusi Impor-Ekspor</h5>
                                    <div class="chart-area">
                                        <canvas id="pieChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Tren Waktu</h5>
                                    <div class="chart-area">
                                        <canvas id="lineChartCombined"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
	            </div>
            </div>
            </div>
        </div>
        <a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/theme.js"></script>
	<script src="assets/js/chart.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script>
    var data = {
    labels: ['Impor Barang', 'Ekspor Barang'],
    datasets: [{
        data: [<?php echo $impor_count; ?>, <?php echo $ekspor_count; ?>],
        backgroundColor: ['#008DDA', '#41C9E2']
        }]
    };
        var options = {
            maintainAspectRatio: false,
            legend: {
                position: 'bottom',
                labels: {
                    fontColor: '#333',
                    fontStyle: 'normal'
                }
            }
        };
        var ctx = document.getElementById('pieChart').getContext('2d');
        var pieChart = new Chart(ctx, {
            type: 'pie',
            data: data,
            options: options
        });
    </script>
	<script>
    var data_combined = {
        labels: <?php echo json_encode($data_impor['dates']); ?>,
        datasets: [{
            label: 'Jumlah Impor',
            data: <?php echo json_encode($data_impor['counts']); ?>,
            borderColor: 'rgb(255, 99, 132)',
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            fill: false
        }, {
            label: 'Jumlah Ekspor',
            data: <?php echo json_encode($data_ekspor['counts']); ?>,
            borderColor: 'rgb(54, 162, 235)',
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            fill: false
        }]
    };
    var options = {
        scales: {
            x: {
                type: 'time',
                time: {
                    unit: 'day'
                }
            },
            y: {
                beginAtZero: true
            }
        }
    };
    var ctx_combined = document.getElementById('lineChartCombined').getContext('2d');
    var lineChartCombined = new Chart(ctx_combined, {
        type: 'line',
        data: data_combined,
        options: options
    });
</script>
</body>
</html>